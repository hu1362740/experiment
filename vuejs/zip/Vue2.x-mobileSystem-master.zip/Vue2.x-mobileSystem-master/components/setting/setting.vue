<template>
	<div>
		设置
	</div>
</template>

<script>
	export default {
		data(){
			return {

			}
		}
	}
</script>

<style></style>