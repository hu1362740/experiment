/**
 * Created by Administrator on 2016/11/25.
 */
export default
[{"title": "张杰 - Give You My World【间谍同盟全球推广曲】", "hash": "EA825985DC03A32CC140F45E496264E2"}, {
  "title": "金志文 - 撒哈拉的花",
  "hash": "61B24814E3ACC76A5A38CDD9DC048A0E"
}, {"title": "吴莫愁 - 完美的你【国际艾滋病日宣传曲】", "hash": "7426D774955FA4F5A6A42236900AE535"}, {
  "title": "张阳阳 - 未什么来",
  "hash": "A2C23BA52DA684D94DCA3D17BC82F9F0"
}, {"title": "林俊杰 - 你是我的唯一(Live)", "hash": "12EDB222CB441906CCCFAD164FC556E2"}, {
  "title": "大张伟 - 哈鹿哈鹿哈鹿【无敌小鹿主题曲】",
  "hash": "4AE9BD06730C7B11470AFA4D0386D98F"
}, {"title": "陈粒 - 当我在这里【我在故宫修文物主题曲】", "hash": "4748F7E256295AD90CA9A2465F707CCC"}, {
  "title": "门丽 - 阡陌红尘",
  "hash": "12E9C3E5AA7EDD1A4C91D449169043AE"
}, {"title": "李阳 - 我想和你走下去【欢喜密探插曲】", "hash": "CC1C2EFC916131D540A837146B16B698"}, {
  "title": "乌兰图雅 - 欢乐的歌儿唱起来",
  "hash": "2CCD3A3197271131823846CD6CE1A830"
}, {"title": "高泰宇 - 念你时说晚安", "hash": "9BDEE92F79368BF0D6234A7767167D08"}, {
  "title": "安东阳 - 红尘私语",
  "hash": "DF3B25B4DE303D2CA80579364FBF844F"
}, {"title": "金志文 - 生之门【生门主题曲】", "hash": "96506A262983EABD951519F9C3C3335A"}, {
  "title": "邓少锋 - 看不见的爱情【深爱食堂2片尾曲】",
  "hash": "6686C81D8E909991D7BA5A4DE1F4AD83"
}, {
  "title": "贾乃亮、张继科、孙杨、徐海乔 - 看你往哪跑【看你往哪跑主题曲】",
  "hash": "200571231C2869AD124383B4E05265BA"
}, {
  "title": "乔紫乔 - 不要每天陪我聊天因为我害怕会喜欢上你",
  "hash": "7F578F2C7039B409CE8DF4352C16A910"
}, {"title": "艾丽雅 - Miss Rain & Mr. Wind", "hash": "695E6FBF8FA89C82CB60C140A6BD6A2C"}, {
  "title": "南征北战 - 天高路远",
  "hash": "84ED99E4F1D6772BD1DCD614017F59AF"
}, {"title": "云飞儿 - 爱与愿违", "hash": "7358829F6775064E7CABF4B33ECE9392"}, {
  "title": "华晨宇 - 我的滑板鞋2016",
  "hash": "8D6C5EFEB211F11FBA781DEE086F8949"
}, {"title": "罗中旭 - I'm OK", "hash": "7C99E1756E0378E961F7795EDAF9C93E"}, {
  "title": "张羽 - 思念大海",
  "hash": "2F1D3D23960462B4C6BF09D4E710B0C8"
}, {"title": "CNBALLER - 一起啦啦啦啦啦啦啦啦啦", "hash": "B4F59BA17852D15429207E9698F1C166"}, {
  "title": "徐佳莹 - 当我找到了你【28岁未成年推广曲】",
  "hash": "01974D2645BCDBA215638430D2F598C0"
}]

