export const validate_token = {
	"validate_token": "cd8f6585f98d503935bd175295b37ae621c0bf06949a46c226125f28d8efd0a9"
};

export const userInfo = {
	"avatar": "e3c1b9262cfb2c65fa3054d54cfaec54jpeg",
	"balance": 0,
	"brand_member_new": 0,
	"column_desc": {
		"game_desc": "玩游戏领红包",
		"game_image_hash": "05f108ca4e0c543488799f0c7c708cb1jpeg",
		"game_is_show": 1,
		"game_link": "https://gamecenter.faas.ele.me",
		"gift_mall_desc": "0元好物在这里"
	},
	"current_address_id": 0,
	"current_invoice_id": 0,
	"delivery_card_expire_days": 0,
	"email": "",
	"gift_amount": 7,
	"id": 186335200,
	"is_active": 1,
	"is_email_valid": false,
	"is_mobile_valid": false,
	"mobile": "13681711268",
	"point": 0,
	"user_id": 186655961,
	"username": "cangdu666"
};

export const checkExsis = {
	"message": "\u8bf7\u68c0\u67e5\u624b\u673a\u53f7\u7801\u683c\u5f0f\u662f\u5426\u6709\u8bef",
	"name": "VALIDATION_FAILED"
};

export const send = {
	"message": "\u9a8c\u8bc1\u7801\u9519\u8bef\uff0c\u8bf7\u91cd\u65b0\u586b\u5199",
	"name": "CAPTCHA_CODE_ERROR"
};

export const cpatchs = {"code":"5aa23c2c99b89d15ab967e8fcddd17ed3526f7ef"};